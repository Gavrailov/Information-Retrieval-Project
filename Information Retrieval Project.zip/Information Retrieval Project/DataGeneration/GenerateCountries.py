import requests
import os
import glob

corpus_path = "corpus/countries.txt"

file = open(corpus_path, 'r')
countries = file.readlines()
dir_country = "DataGeneration/countries"


# Clear existing files in the dir
# for f in existing_files:
#     os.remove(f)

for country in countries:
    country = country.strip()
    response = requests.get('https://en.wikipedia.org/w/api.php',params={'action': 'query','format': 'json','titles': country,'prop': 'extracts','explaintext': True,'exlimit': 'max',}).json()
    page = next(iter(response['query']['pages'].values()))
    content=(page['extract'])
    file_title=country.replace(" ", "_")

    file_to_save = open(dir_country + "/" + file_title, "w+", encoding="utf-8")
    file_to_save.write(content)
    file_to_save.close()
file.close()

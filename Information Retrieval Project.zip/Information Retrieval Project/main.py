from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy
from spacy import displacy
from spacy.matcher import PhraseMatcher
from pathlib import Path
import os
import sys

sys.path.insert(1, 'utils')
sys.path.insert(1, 'DataGeneration')
sys.path.insert(1, 'VectorSpaceModel')


import utils
import VectorSpaceModel


data = utils.loadDate('DataGeneration/countries', 22)

# Lemmatizing
utils.preprocessData(data)

# VECTOR SPACE MODEL
# vec = TfidfVectorizer(norm=None, ngram_range=(1, 3))
vec = TfidfVectorizer(norm=None)
corpus = vec.fit_transform(data)

# Logic
def run_query(query):

    preprocessed_query = utils.preprocessText(query)

    result = VectorSpaceModel.vectorSpaceModel(data, vec, corpus, preprocessed_query, 5)

    print(result)

def root_dir():  
    return os.path.abspath(os.path.dirname(__file__))

def get_file(filename): 
    try:
        src = os.path.join(root_dir(), filename)
        return open(src).read()
    except IOError as exc:
        return str(exc)

run_query("Which country is founded in 681 AD?")
